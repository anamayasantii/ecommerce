<?php
require_once(__DIR__ . '/../Config/init.php');

$categoryId = $_GET['id'];

$categoryController = new CategoryController();
$category = $categoryController->show($categoryId);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["restoreAllCategories"])) {
    $categoryController->restore();
    header("Location: categories.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h2>Category Details</h2>
        <a href="../categories.php" class="btn btn-secondary mb-3">Back to Categories</a>

        <?php if ($category) : ?>
            <table class="table table-bordered">
                <tr>
                    <th>ID:</th>
                    <td><?php echo htmlspecialchars($category["id"]); ?></td>
                </tr>
                <tr>
                    <th>Category Name:</th>
                    <td><?php echo htmlspecialchars($category["category_name"]); ?></td>
                </tr>
            </table>

            <form action="" method="post">
                <input type="hidden" name="restoreAllCategories" value="1">
                <button type="submit" class="btn btn-warning">Restore All Categories</button>
            </form>
        <?php else : ?>
            <p class="text-warning">Category not found!</p>
        <?php endif ?>
    </div>
</body>
</html>
