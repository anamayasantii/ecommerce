<?php
require_once(__DIR__ . '/../Config/init.php');

$categoryId = $_GET['id'];
$categoryController = new CategoryController();
$category = $categoryController->show($categoryId);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['category_name'])) {
    if (empty($_POST['category_name'])) {
        $errors['category_name'] = "Category Name is required";
    } else {
        $data = ['category_name' => $_POST['category_name']];
        if (empty($errors)) {
            if ($categoryController->update($categoryId, $data)) {
                echo "<script>alert('Category updated successfully!');</script>";
                header("Location: ../categories.php");
                exit();
            } else {
                echo "<script>alert('Failed to update category!');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Category</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container { max-width: 600px; }
        .btn-custom {
            background-color: #ec407a;
            color: #fff;
            border: none;
        }
        .btn-custom:hover {
            background-color: #d81b60;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h2 class="mb-4">Update Category</h2>
        <a href="../categories.php" class="btn btn-custom mb-3">Back to Categories</a>

        <?php if ($category) : ?>
            <form action="" method="post">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($category['id']); ?>">

                <div class="mb-3">
                    <label for="category_name" class="form-label">Category Name:</label>
                    <input type="text" name="category_name" class="form-control <?php echo isset($errors['category_name']) ? 'is-invalid' : ''; ?>" 
                           value="<?php echo htmlspecialchars($category['category_name']); ?>" required>
                    <?php if (isset($errors['category_name'])) : ?>
                        <div class="invalid-feedback"><?php echo $errors['category_name']; ?></div>
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-custom">Update Category</button>
            </form>
        <?php else : ?>
            <p class="text-danger">Data not found</p>
        <?php endif; ?>
    </div>
</body>
</html>
