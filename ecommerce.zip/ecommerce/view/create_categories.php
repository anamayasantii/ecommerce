<?php
require(__DIR__ . '/../Config/init.php');

$categoryController = new CategoryController();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['category_name'])) {
    $category_name = trim($_POST['category_name']);

    // Validate category name
    if (empty($category_name)) {
        $errors['category_name'] = "Category name is required.";
    } elseif (strlen($category_name) > 50) {
        $errors['category_name'] = "Category name must be less than 50 characters.";
    }

    // If there are no validation errors, proceed with creating the category
    if (empty($errors)) {
        $data = ['category_name' => $category_name];
        if ($categoryController->create($data)) {
            echo "<script>alert('Category added successfully!');</script>";
            header("Location: ../categories.php");
            exit();
        } else {
            echo "<script>alert('Failed to add category!');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Category</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h2>Create Category</h2>
        <a href="../categories.php" class="btn btn-secondary mb-3">Back to Categories</a>

        <form action="" method="post">
            <div class="mb-3">
                <label for="category_name" class="form-label">Category Name:</label>
                <input type="text" name="category_name" class="form-control" required>
                <?php if (isset($errors['category_name'])): ?>
                    <div class="text-danger"><?php echo htmlspecialchars($errors['category_name']); ?></div>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary">Add Category</button>
        </form>
    </div>
</body>
</html>
