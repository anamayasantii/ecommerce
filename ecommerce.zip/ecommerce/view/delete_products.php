<?php
require_once(__DIR__ . '/../Config/init.php');

$productId = $_GET['id'];
$productController = new ProductController();
$products = $productController->show($productId);

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($productController->destroy($productId)) {
        echo "<script>alert('Product deleted successfully!');</script>";
        header("Location: ../index.php");
        exit();
    } else {
        echo "<script>alert('Failed to delete product!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h2 class="text-danger mb-4">Delete Product</h2>
        <a href="../index.php" class="btn btn-secondary mb-3">Back to Product List</a>

        <?php if ($products) : ?>
            <div class="alert alert-warning" role="alert">
                <strong>Warning:</strong> You are about to delete the following product. This action cannot be undone.
            </div>
            
            <table class="table table-bordered">
                <tr>
                    <th>ID:</th>
                    <td><?php echo htmlspecialchars($products["id"]); ?></td>
                </tr>
                <tr>
                    <th>Product Name:</th>
                    <td><?php echo htmlspecialchars($products["product_name"]); ?></td>
                </tr>
                <tr>
                    <th>Category:</th>
                    <td><?php echo htmlspecialchars($products["category_name"]); ?></td>
                </tr>
                <tr>
                    <th>Price:</th>
                    <td><?php echo htmlspecialchars($products["price"]); ?></td>
                </tr>
                <tr>
                    <th>Stock:</th>
                    <td><?php echo htmlspecialchars($products["stock"]); ?></td>
                </tr>
            </table>

            <form action="" method="post">
                <input type="hidden" name="id" value="<?php echo htmlspecialchars($products['id']); ?>">
                <button type="submit" class="btn btn-danger">Confirm Delete</button>
                <a href="../index.php" class="btn btn-secondary">Cancel</a>
            </form>
        <?php else : ?>
            <p class="text-danger">Product data not found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
