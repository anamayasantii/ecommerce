<?php

require(__DIR__ . '/../Config/init.php');

class Product extends Model
{
    /**
     * Constructor that calls the parent constructor and sets the table name for this class.
     * $this->tableName is refers to the table name in the database which will be used by this model.
     * $this->setTableName is a method from the parent class that sets the table name.
     */
    public function __construct()
    {
        parent::__construct();
        $this->setTableName('products');
    }

    /**
     * Method  to get all products from the database and return the result as an associative array.
     */
    public function getAllProducts()
    {
        // call database selectData
        // return fetched data
        $stmt = $this->db->selectData($this->tableName, null, 0);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

//Jika Anda ingin mengakses category_name, Anda harus memastikan 
//bahwa data tersebut termasuk dalam hasil query, misalnya melalui JOIN 
//dengan tabel kategori.
    public function getProductById($id)
    {
        $query = "
        SELECT p.*, c.category_name 
        FROM products p
        JOIN categories c ON p.category_id = c.id
        WHERE p.id = :id
    ";
    $stmt = $this->db->getInstance()->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC); // Menggunakan fetch() untuk mengambil satu baris data
    //Dengan query di atas, Anda akan mendapatkan kolom category_name dari tabel kategori dan menggabungkannya dengan data produk.
    }

    public function createProduct($data)
    {
        // construct data as array association
        // call database insertData and pass the constructed data
        // return boolean
        $fillable = [
            'product_name' => $data['product_name'],
            'category_id' => $data['category_id'],
            'price' => $data['price'],
            'stock' => $data['stock']
        ];        
        $stmt = $this->db->insertData($this->tableName, $fillable);
        return $stmt;
    }

    public function updateProduct($id, $data)
    {
        $stmt = $this->db->updateData($this->tableName, $id, $data);
        return $stmt;
    }


    public function deleteProduct($id)
    {
        // call deteleRecord
        $this->db->deleteRecord($this->tableName, $id);
    }

    public function restoreProduct()
    {
        // call deteleRecord
        $this->db->restoreRecord($this->tableName);
    }

    /**
     * Metode untuk mendapatkan semua produk beserta nama kategori yang terkait.
     */
    public function getAllProductsWithCategories()
    {
        // Gunakan metode query join database untuk mengambil produk beserta kategori mereka
        $stmt = $this->db->getProductsWithCategories();
        return $stmt;
    }
}
