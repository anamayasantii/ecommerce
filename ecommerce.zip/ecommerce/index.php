<?php
require_once(__DIR__ . '/Config/init.php');

$productController = new ProductController();
$products = $productController->index();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["restoreProduct"])) {
    $productController->restore();
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table th {
            background-color: #f8bbd0; /* Light pink header */
            color: #ffffff;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #fde4ec; /* Light pink for striped rows */
        }
        .table-hover tbody tr:hover {
            background-color: #f48fb1; /* Darker pink on hover */
            color: #fff;
        }
        .btn-custom {
            background-color: #ec407a;
            color: #fff;
            border: none;
        }
        .btn-custom:hover {
            background-color: #d81b60;
        }
        .btn-lain {
            background-color: #608BC1;
            color: #fff;
            border: none;
        }
        .btn-restore {
            background-color: #E78F81;
            color: #fff;
            border: none;
        }
    </style>
</head>
<body>
    <div class="container my-4">
        <h2>Product List</h2>
        <a href="categories.php" class="btn btn-lain mb-2">View Categories</a>
        <a href="view/create_products.php" class="btn btn-custom mb-2">Add Product</a>
        <br><br>

        <form method="POST">
            <button type="submit" name="restoreProduct" class="btn btn-restore">Restore All Products</button>
        </form>

        <table class="table table-striped table-hover mt-3">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Category</th>
                    <th scope="col">Price</th>
                    <th scope="col">Stock</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($products) : ?>
                    <?php $counter = 1; ?>
                    <?php foreach ($products as $product) : ?>
                        <tr>
                            <th scope="row"><?php echo $counter; ?></th>
                            <td><?php echo $product["product_name"]; ?></td>
                            <td><?php echo $product["category_name"] ?? 'No Category'; ?></td>
                            <td><?php echo $product["price"]; ?></td>
                            <td><?php echo $product["stock"]; ?></td>
                            <td>
                                <a href="view/detail_products.php?id=<?php echo $product["id"]; ?>" class="btn btn-sm btn-custom">View</a>
                                <a href="view/update_products.php?id=<?php echo $product["id"]; ?>" class="btn btn-sm btn-custom">Update</a>
                                <a href="view/delete_products.php?id=<?php echo $product["id"]; ?>" class="btn btn-sm btn-custom">Delete</a>
                            </td>
                        </tr>
                        <?php $counter++; ?>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="6">0 result</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
