<?php
require(__DIR__ . '/../Config/init.php');
class CategoryController
{
    private $categoryModel;

    public function __construct()
    {
        $this->categoryModel = new Category();
    }

    /**
     * Index: this method allows users to  view all products in the database.
     */
    public function index() {
        $result = $this->categoryModel->getAllCategories();

        return $result;
    }

    /**
     * Create: this method allows user to create a new product
     */
    public function create($data) {
        try {
            $this->categoryModel->createCategory($data);
            return true;
        } catch (PDOException $e) {
            die ("Error: " . $e->getMessage());
        }
    }
    /**
     * Show: This method is used to show one specific product by its id.
     *   @param int $id - The id of the product that needs to be shown.
     *   @return array $product - An associative array containing information about the selected product.
     *   If no product with the given id exists, an empty array will be returned.
     */
    public function show($id) {
        $category = $this->categoryModel->getCategoryById($id);

        return $category;
    }

    public function update($id, $data) {
        try {
            $this->categoryModel->updateCategory($id, $data);
            return true;
        } catch (PDOException $e) {
            die("Error updating record: " . $e->getMessage());
        }
    }

    public function destroy($id) {
        $this->categoryModel->deleteCategory($id);
        $result = $this->categoryModel->getCategoryById($id);
        return $result === null || empty($result);
    }

    public function restore() {
        $this->categoryModel->restoreCategory();
    }


}
