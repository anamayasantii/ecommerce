<?php
require_once(__DIR__ . '/Config/init.php');

$categoryController = new CategoryController();
$categories = $categoryController->index();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["restoreAllCategories"])) {
    $categoryController->restore();
    header("Location: categories.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table th {
            background-color: #f8bbd0; /* Light pink header */
            color: #ffffff;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #fde4ec; /* Light pink for striped rows */
        }
        .table-hover tbody tr:hover {
            background-color: #f48fb1; /* Darker pink on hover */
            color: #fff;
        }
        .btn-custom {
            background-color: #ec407a;
            color: #fff;
            border: none;
        }
        .btn-custom:hover {
            background-color: #d81b60;
        }
        .btn-lain {
            background-color: #608BC1;
            color: #fff;
            border: none;
        }
        .btn-restore {
            background-color: #E78F81;
            color: #fff;
            border: none;
        }
    </style>
</head>
<body>
    <div class="container my-4">
        <h2>Category List</h2>
        <a href="index.php" class="btn btn-lain mb-2">See Products</a>
        <a href="view/create_categories.php" class="btn btn-custom mb-2">Add Category</a>
        <br><br>

        <form method="POST">
            <button type="submit" name="restoreAllCategories" class="btn btn-restore">Restore All Categories</button>
        </form>

        <table class="table table-striped table-hover mt-3">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Category</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($categories)) : ?>
                    <?php $counter = 1; ?>
                    <?php foreach ($categories as $category) : ?>
                        <tr>
                            <th scope="row"><?php echo $counter; ?></th>
                            <td><?php echo $category["category_name"]; ?></td>
                            <td>
                                <a href="view/detail_categories.php?id=<?php echo $category["id"]; ?>" class="btn btn-sm btn-custom">View</a>
                                <a href="view/update_categories.php?id=<?php echo $category["id"]; ?>" class="btn btn-sm btn-custom">Update</a>
                                <a href="view/delete_categories.php?id=<?php echo $category["id"]; ?>" class="btn btn-sm btn-custom">Delete</a>
                            </td>
                        </tr>
                        <?php $counter++; ?>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="3">0 result</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
